import React, { useState } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import DatasetOverview from './components/DatasetOverview';
import DataVisualization from './components/DataVisualization';
import FeatureAnalysis from './components/FeatureAnalysis';
import ModelTraining from './components/ModelTraining';
import PredictionInterface from './components/PredictionInterface';

function App() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <DatasetOverview />;
      case 'visualization':
        return <DataVisualization />;
      case 'analysis':
        return <FeatureAnalysis />;
      case 'training':
        return <ModelTraining />;
      case 'prediction':
        return <PredictionInterface />;
      default:
        return <DatasetOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="container mx-auto px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center text-gray-600">
            <p className="mb-2">Music Popularity Prediction Platform</p>
            <p className="text-sm">
              Built with React, TypeScript, and Tailwind CSS • 
              <a href="https://drive.google.com/drive/u/5/folders/1g2_Ku6oRsY8cV8dz9DRtKMwaXhSTMmsU" 
                 target="_blank" 
                 rel="noopener noreferrer" 
                 className="text-blue-600 hover:text-blue-800 ml-1">
                View Dataset
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;