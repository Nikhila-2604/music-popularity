import React from 'react';
import { Music, TrendingUp, BarChart3 } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 text-white shadow-lg">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Music className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Music Popularity Predictor</h1>
              <p className="text-purple-100 text-sm">AI-Powered Music Analytics Platform</p>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
              <TrendingUp className="h-4 w-4" />
              <span className="text-sm font-medium">227 Tracks</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
              <BarChart3 className="h-4 w-4" />
              <span className="text-sm font-medium">ML Ready</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;