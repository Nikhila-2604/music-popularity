import React from 'react';
import { BarChart, TrendingUp, Music, Zap } from 'lucide-react';

const FeatureAnalysis: React.FC = () => {
  const featureImportance = [
    { feature: 'Danceability', importance: 0.18, color: 'bg-red-500' },
    { feature: 'Energy', importance: 0.16, color: 'bg-orange-500' },
    { feature: 'Valence', importance: 0.14, color: 'bg-yellow-500' },
    { feature: 'Tempo', importance: 0.12, color: 'bg-green-500' },
    { feature: 'Acousticness', importance: 0.10, color: 'bg-blue-500' },
    { feature: 'Instrumentalness', importance: 0.09, color: 'bg-indigo-500' },
    { feature: 'Liveness', importance: 0.08, color: 'bg-purple-500' },
    { feature: 'Speechiness', importance: 0.07, color: 'bg-pink-500' },
    { feature: 'Loudness', importance: 0.06, color: 'bg-gray-500' },
  ];

  const correlations = [
    { feature1: 'Energy', feature2: 'Loudness', correlation: 0.73, type: 'positive' },
    { feature1: 'Valence', feature2: 'Danceability', correlation: 0.68, type: 'positive' },
    { feature1: 'Acousticness', feature2: 'Energy', correlation: -0.65, type: 'negative' },
    { feature1: 'Instrumentalness', feature2: 'Speechiness', correlation: -0.58, type: 'negative' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Feature Analysis</h2>
        <div className="flex items-center space-x-2">
          <BarChart className="h-5 w-5 text-gray-500" />
          <span className="text-sm text-gray-600">Statistical Insights</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Feature Importance */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            <span>Feature Importance</span>
          </h3>
          <div className="space-y-3">
            {featureImportance.map((item, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-24 text-sm text-gray-600">{item.feature}</div>
                <div className="flex-1 bg-gray-200 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full ${item.color}`}
                    style={{ width: `${item.importance * 100}%` }}
                  ></div>
                </div>
                <div className="text-sm font-medium text-gray-800 w-12">
                  {(item.importance * 100).toFixed(0)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Correlations */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <Zap className="h-5 w-5 text-purple-600" />
            <span>Feature Correlations</span>
          </h3>
          <div className="space-y-3">
            {correlations.map((item, index) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Music className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-medium text-gray-800">
                      {item.feature1} ↔ {item.feature2}
                    </span>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    item.type === 'positive' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {item.correlation > 0 ? '+' : ''}{item.correlation}
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div
                    className={`h-1.5 rounded-full ${
                      item.type === 'positive' ? 'bg-green-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${Math.abs(item.correlation) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Insights */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h4 className="font-semibold text-blue-800 mb-2">Key Insights</h4>
        <ul className="space-y-1 text-sm text-blue-700">
          <li>• Danceability and Energy are the strongest predictors of music popularity</li>
          <li>• High correlation between Energy and Loudness suggests they measure similar aspects</li>
          <li>• Acoustic tracks tend to have lower energy levels</li>
          <li>• Valence (musical positivity) correlates with danceability</li>
        </ul>
      </div>
    </div>
  );
};

export default FeatureAnalysis;