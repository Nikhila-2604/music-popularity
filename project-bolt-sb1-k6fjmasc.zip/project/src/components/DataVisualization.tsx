import React from 'react';
import { BarChart3, PieChart, LineChart, Activity } from 'lucide-react';

const DataVisualization: React.FC = () => {
  const popularityDistribution = [
    { range: '0-20', count: 45, color: 'bg-red-500' },
    { range: '21-40', count: 68, color: 'bg-orange-500' },
    { range: '41-60', count: 72, color: 'bg-yellow-500' },
    { range: '61-80', count: 32, color: 'bg-green-500' },
    { range: '81-100', count: 10, color: 'bg-blue-500' },
  ];

  const genreAnalysis = [
    { genre: 'Pop', avgPopularity: 72, count: 45, color: 'bg-pink-500' },
    { genre: 'Rock', avgPopularity: 68, count: 38, color: 'bg-purple-500' },
    { genre: 'Hip-Hop', avgPopularity: 75, count: 32, color: 'bg-indigo-500' },
    { genre: 'Electronic', avgPopularity: 65, count: 28, color: 'bg-blue-500' },
    { genre: 'Jazz', avgPopularity: 58, count: 22, color: 'bg-green-500' },
    { genre: 'Classical', avgPopularity: 45, count: 18, color: 'bg-yellow-500' },
  ];

  const timeSeriesData = [
    { year: '2018', popularity: 58 },
    { year: '2019', popularity: 62 },
    { year: '2020', popularity: 67 },
    { year: '2021', popularity: 71 },
    { year: '2022', popularity: 69 },
    { year: '2023', popularity: 73 },
  ];

  const maxCount = Math.max(...popularityDistribution.map(d => d.count));

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Data Visualization</h2>
        <div className="flex items-center space-x-2">
          <Activity className="h-5 w-5 text-gray-500" />
          <span className="text-sm text-gray-600">Interactive Charts</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Popularity Distribution */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            <span>Popularity Distribution</span>
          </h3>
          <div className="space-y-3">
            {popularityDistribution.map((item, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-16 text-sm text-gray-600">{item.range}</div>
                <div className="flex-1 bg-gray-200 rounded-full h-6 relative">
                  <div
                    className={`h-6 rounded-full ${item.color} transition-all duration-1000`}
                    style={{ width: `${(item.count / maxCount) * 100}%` }}
                  ></div>
                  <div className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white">
                    {item.count}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Genre Analysis */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <PieChart className="h-5 w-5 text-purple-600" />
            <span>Genre Analysis</span>
          </h3>
          <div className="space-y-3">
            {genreAnalysis.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-sm font-medium text-gray-800">{item.genre}</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-800">{item.avgPopularity}%</div>
                    <div className="text-xs text-gray-500">Avg Popularity</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-800">{item.count}</div>
                    <div className="text-xs text-gray-500">Tracks</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Time Series */}
        <div className="lg:col-span-2">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <LineChart className="h-5 w-5 text-green-600" />
            <span>Popularity Trends Over Time</span>
          </h3>
          <div className="relative h-40 bg-gray-50 rounded-lg p-4">
            <div className="flex items-end justify-between h-full">
              {timeSeriesData.map((item, index) => (
                <div key={index} className="flex flex-col items-center space-y-2">
                  <div className="text-xs text-gray-600">{item.popularity}%</div>
                  <div
                    className="bg-gradient-to-t from-green-500 to-green-400 rounded-t-sm w-8 transition-all duration-1000"
                    style={{ height: `${(item.popularity / 100) * 100}%` }}
                  ></div>
                  <div className="text-xs text-gray-600">{item.year}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-blue-600">62.4%</div>
          <div className="text-sm text-gray-600">Average Popularity</div>
        </div>
        <div className="bg-green-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-green-600">95</div>
          <div className="text-sm text-gray-600">Highest Score</div>
        </div>
        <div className="bg-orange-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-orange-600">18.5</div>
          <div className="text-sm text-gray-600">Standard Deviation</div>
        </div>
        <div className="bg-purple-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-purple-600">Hip-Hop</div>
          <div className="text-sm text-gray-600">Top Genre</div>
        </div>
      </div>
    </div>
  );
};

export default DataVisualization;