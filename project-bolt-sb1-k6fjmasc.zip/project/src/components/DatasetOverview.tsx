import React from 'react';
import { Database, FileText, Calendar, Users } from 'lucide-react';

const DatasetOverview: React.FC = () => {
  const features = [
    { name: 'Audio Features', count: '13+', icon: Database, color: 'bg-blue-500' },
    { name: 'Track Metadata', count: '227', icon: FileText, color: 'bg-green-500' },
    { name: 'Release Dates', count: '100%', icon: Calendar, color: 'bg-orange-500' },
    { name: 'Artist Info', count: '227', icon: Users, color: 'bg-purple-500' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Dataset Overview</h2>
        <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
          Ready for Analysis
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {features.map((feature, index) => (
          <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex items-center space-x-3">
              <div className={`${feature.color} p-2 rounded-lg`}>
                <feature.icon className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{feature.name}</p>
                <p className="text-xl font-bold text-gray-800">{feature.count}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-semibold text-gray-800 mb-3">Key Features Available</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {[
            'Danceability', 'Energy', 'Valence', 'Tempo', 'Acousticness', 'Instrumentalness',
            'Liveness', 'Speechiness', 'Loudness', 'Duration', 'Key', 'Mode', 'Time Signature'
          ].map((feature, index) => (
            <span key={index} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 shadow-sm">
              {feature}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DatasetOverview;