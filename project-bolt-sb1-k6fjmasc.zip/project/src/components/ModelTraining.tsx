import React, { useState } from 'react';
import { Play, Settings, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';

const ModelTraining: React.FC = () => {
  const [isTraining, setIsTraining] = useState(false);
  const [trainingComplete, setTrainingComplete] = useState(false);
  const [selectedModel, setSelectedModel] = useState('random_forest');

  const models = [
    { id: 'random_forest', name: 'Random Forest', accuracy: '87.3%', description: 'Best for feature importance' },
    { id: 'xgboost', name: 'XGBoost', accuracy: '89.1%', description: 'Highest accuracy' },
    { id: 'linear_regression', name: 'Linear Regression', accuracy: '78.9%', description: 'Simple and interpretable' },
    { id: 'neural_network', name: 'Neural Network', accuracy: '85.7%', description: 'Deep learning approach' },
  ];

  const handleTraining = () => {
    setIsTraining(true);
    setTrainingComplete(false);
    
    // Simulate training process
    setTimeout(() => {
      setIsTraining(false);
      setTrainingComplete(true);
    }, 3000);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Model Training</h2>
        <div className="flex items-center space-x-2">
          <Settings className="h-5 w-5 text-gray-500" />
          <span className="text-sm text-gray-600">Configuration</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Model Selection */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4">Select Model</h3>
          <div className="space-y-3">
            {models.map((model) => (
              <div
                key={model.id}
                className={`p-4 border rounded-lg cursor-pointer transition-all ${
                  selectedModel === model.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => setSelectedModel(model.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-800">{model.name}</p>
                    <p className="text-sm text-gray-600">{model.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-green-600">{model.accuracy}</p>
                    <p className="text-xs text-gray-500">Accuracy</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Training Controls */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4">Training Configuration</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Train/Test Split
              </label>
              <select className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option>80/20</option>
                <option>70/30</option>
                <option>90/10</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cross Validation
              </label>
              <select className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option>5-Fold</option>
                <option>10-Fold</option>
                <option>Leave-One-Out</option>
              </select>
            </div>

            <div className="pt-4">
              <button
                onClick={handleTraining}
                disabled={isTraining}
                className={`w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all ${
                  isTraining
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {isTraining ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Training...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5" />
                    <span>Start Training</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Training Results */}
      {trainingComplete && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center space-x-2 mb-3">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="font-medium text-green-800">Training Complete!</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">89.1%</p>
              <p className="text-sm text-gray-600">Accuracy</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">0.87</p>
              <p className="text-sm text-gray-600">R² Score</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">0.23</p>
              <p className="text-sm text-gray-600">RMSE</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelTraining;