import React, { useState } from 'react';
import { Target, Sparkles, Music, TrendingUp } from 'lucide-react';

const PredictionInterface: React.FC = () => {
  const [prediction, setPrediction] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    danceability: 0.5,
    energy: 0.5,
    valence: 0.5,
    tempo: 120,
    acousticness: 0.5,
    instrumentalness: 0.5,
    liveness: 0.5,
    speechiness: 0.5,
    loudness: -10,
  });

  const handleInputChange = (feature: string, value: number) => {
    setFormData(prev => ({
      ...prev,
      [feature]: value
    }));
  };

  const handlePredict = () => {
    setIsLoading(true);
    setPrediction(null);
    
    // Simulate prediction
    setTimeout(() => {
      // Mock prediction based on features
      const score = (
        formData.danceability * 0.18 +
        formData.energy * 0.16 +
        formData.valence * 0.14 +
        (formData.tempo / 200) * 0.12 +
        formData.acousticness * 0.10 +
        formData.instrumentalness * 0.09 +
        formData.liveness * 0.08 +
        formData.speechiness * 0.07 +
        ((formData.loudness + 20) / 20) * 0.06
      );
      
      setPrediction(Math.max(0, Math.min(100, score * 100)));
      setIsLoading(false);
    }, 2000);
  };

  const featureInputs = [
    { key: 'danceability', label: 'Danceability', min: 0, max: 1, step: 0.01 },
    { key: 'energy', label: 'Energy', min: 0, max: 1, step: 0.01 },
    { key: 'valence', label: 'Valence', min: 0, max: 1, step: 0.01 },
    { key: 'tempo', label: 'Tempo (BPM)', min: 60, max: 200, step: 1 },
    { key: 'acousticness', label: 'Acousticness', min: 0, max: 1, step: 0.01 },
    { key: 'instrumentalness', label: 'Instrumentalness', min: 0, max: 1, step: 0.01 },
    { key: 'liveness', label: 'Liveness', min: 0, max: 1, step: 0.01 },
    { key: 'speechiness', label: 'Speechiness', min: 0, max: 1, step: 0.01 },
    { key: 'loudness', label: 'Loudness (dB)', min: -30, max: 0, step: 0.1 },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Popularity Prediction</h2>
        <div className="flex items-center space-x-2">
          <Target className="h-5 w-5 text-gray-500" />
          <span className="text-sm text-gray-600">Interactive Predictor</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Controls */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <Music className="h-5 w-5 text-blue-600" />
            <span>Song Features</span>
          </h3>
          <div className="space-y-4">
            {featureInputs.map((feature) => (
              <div key={feature.key}>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {feature.label}
                </label>
                <div className="flex items-center space-x-3">
                  <input
                    type="range"
                    min={feature.min}
                    max={feature.max}
                    step={feature.step}
                    value={formData[feature.key as keyof typeof formData]}
                    onChange={(e) => handleInputChange(feature.key, parseFloat(e.target.value))}
                    className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-sm font-medium text-gray-800 w-16">
                    {formData[feature.key as keyof typeof formData]}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Prediction Results */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            <span>Prediction Results</span>
          </h3>
          
          <div className="space-y-4">
            <button
              onClick={handlePredict}
              disabled={isLoading}
              className={`w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all ${
                isLoading
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700'
              }`}
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Predicting...</span>
                </>
              ) : (
                <>
                  <TrendingUp className="h-5 w-5" />
                  <span>Predict Popularity</span>
                </>
              )}
            </button>

            {prediction !== null && (
              <div className="p-6 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                <div className="text-center">
                  <div className="mb-4">
                    <div className="text-4xl font-bold text-purple-600 mb-2">
                      {prediction.toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-600">Predicted Popularity Score</div>
                  </div>
                  
                  <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                    <div
                      className="bg-gradient-to-r from-purple-500 to-blue-500 h-3 rounded-full transition-all duration-1000"
                      style={{ width: `${prediction}%` }}
                    ></div>
                  </div>
                  
                  <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                    prediction >= 70 
                      ? 'bg-green-100 text-green-800' 
                      : prediction >= 40 
                        ? 'bg-yellow-100 text-yellow-800' 
                        : 'bg-red-100 text-red-800'
                  }`}>
                    {prediction >= 70 ? 'High Potential' : prediction >= 40 ? 'Moderate Potential' : 'Low Potential'}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictionInterface;